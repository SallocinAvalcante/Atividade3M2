# Autores: Augusto Corrêa da Rocha Neto RGM:11221101575 (Código) Gleydson Akiriro RGM: 11221103498  Nicollas Cavalcante RGM:11221104304
# Estrutura lineares - Atividade 3 M2

import customtkinter as ctk
from CTkMessagebox import CTkMessagebox
from PIL import Image, ImageTk
import jogos  # Importa as funções de jogos.py

ctk.set_appearance_mode("dark")  # Modo escuro
ctk.set_default_color_theme("dark-blue")  # Tema azul

# Função para cadastrar jogo
def inserir_jogo():
    id = entry_id.get()
    nome = entry_nome.get()
    genero = entry_genero.get()
    plataforma = entry_plataforma.get()
    preco_bruto = entry_prec_bruto.get()

    sucesso, mensagem = jogos.inserir_jogo(id, nome, genero, plataforma, preco_bruto)

    if sucesso:
        CTkMessagebox(title="Sucesso", message=mensagem, icon="check", button_color="#8A2BE2", button_hover_color="#A020F0")
        limpar_tela()
    else:
        CTkMessagebox(title="Erro", message=mensagem, icon="cancel", button_color="#8A2BE2", button_hover_color="#A020F0")

# Função para consultar jogo
def consultar_jogo_id():
    id = entry_id.get()

    if not id:
        CTkMessagebox(title="Consulta", message="Por favor, informe o ID para consultar.", icon="warning", button_color="#8A2BE2", button_hover_color="#A020F0")
        return

    jogo = jogos.consultar_jogo_id(id)

    if jogo:
        entry_nome.delete(0, ctk.END)
        entry_nome.insert(0, jogo[0])

        entry_genero.delete(0, ctk.END)
        entry_genero.insert(0, jogo[1])

        entry_plataforma.delete(0, ctk.END)
        entry_plataforma.insert(0, jogo[2])

        entry_prec_bruto.delete(0, ctk.END)
        entry_prec_bruto.insert(0, jogo[3])

        CTkMessagebox(title="Consulta", message=f"Jogo encontrado:\nNome: {jogo[0]}\nGenêro: {jogo[1]}\nPlataforma: {jogo[2]}\nPreço Bruto: {jogo[3]}", icon="check",
                       button_color="#8A2BE2",button_hover_color="#A020F0")
    else:
        CTkMessagebox(title="Consulta", message="Jogo não encontrado.", icon="warning")

# Função para mostrar todos os jogos
def mostrar_todos_jogos():
    jogos_lista = jogos.exibir_jogos()

    if not jogos_lista:
        CTkMessagebox(title="Consulta", message="Nenhum jogo encontrado.", icon="warning", button_color="#8A2BE2", button_hover_color="#A020F0")
        return

    jogos_str = "ID - Nome - Genêro - Plataforma - Preço Bruto\n\n"
    for jogo in jogos_lista:
        jogos_str += f"{jogo[0]} - {jogo[1]} - {jogo[2]} - {jogo[3]} - {jogo[4]}\n"

    CTkMessagebox(title="Todos os Jogos", message=jogos_str, icon="Icone_NewGames.ico", width=600, height=300, button_color="#8A2BE2", button_hover_color="#A020F0")

# Função para atualizar jogo
def atualizar_jogo():
    id = entry_id.get()
    nome = entry_nome.get()
    genero = entry_genero.get()
    plataforma = entry_plataforma.get()
    preco_bruto = entry_prec_bruto.get()

    sucesso, mensagem = jogos.atualizar_jogo(id, nome, genero, plataforma, preco_bruto)

    if sucesso:
        CTkMessagebox(title="Sucesso", message=mensagem, icon="check", button_color="#8A2BE2", button_hover_color="#A020F0")
        limpar_tela()
    else:
        CTkMessagebox(title="Erro", message=mensagem, icon="cancel", button_color="#8A2BE2", button_hover_color="#A020F0")

# Função para deletar jogo
def deletar_jogo():
    id = entry_id.get()

    sucesso, mensagem = jogos.deletar_jogo(id)

    if sucesso:
        CTkMessagebox(title="Sucesso", message=mensagem, icon="check", button_color="#8A2BE2", button_hover_color="#A020F0")
        limpar_tela()
    else:
        CTkMessagebox(title="Erro", message=mensagem, icon="cancel", button_color="#8A2BE2", button_hover_color="#A020F0")

# Função de Limpar a tela
def limpar_tela():
    entry_id.delete(0, ctk.END)
    entry_nome.delete(0, ctk.END)
    entry_genero.delete(0, ctk.END)
    entry_plataforma.delete(0, ctk.END)
    entry_prec_bruto.delete(0, ctk.END)
    entry_id.focus()

# Função de sair da janela
def sair():
    opcao = CTkMessagebox(title="Sair", message="Deseja sair?", icon="question", option_2="Sim", option_1="Não", button_color="#8A2BE2", button_hover_color="#A020F0")
    if opcao.get() == "Sim":
        janela.destroy()

# Criação da Janela
janela = ctk.CTk()
janela.title("Cadastro de Jogos")
janela.geometry("400x600")
janela.resizable(False, False)  # Janela com tamanho fixo
janela.iconbitmap("D:\\Faculdade\\Atividade 3 - M2\\Icone_NewGames.ico")

# Imagem no canto superior esquerdo (cabeçalho)
imagem = Image.open("D:\\Faculdade\\Atividade 3 - M2\\Logo_NewGames.png")
imagem = imagem.resize((200, 85))  # Ajustar o tamanho da imagem
imagem_tk = ImageTk.PhotoImage(imagem)
# Frame do cabeçalho
frame_topo = ctk.CTkFrame(janela, fg_color="transparent")
frame_topo.pack(pady=10, anchor='w')  # Alinha à esquerda
label_imagem = ctk.CTkLabel(frame_topo, image=imagem_tk, text="")
label_imagem.pack(side="left", padx=10)

# Campos de entrada
entry_id = ctk.CTkEntry(janela, placeholder_text="ID")
entry_id.pack(pady=10, padx=20, fill="x")

entry_nome = ctk.CTkEntry(janela, placeholder_text="Nome")
entry_nome.pack(pady=10, padx=20, fill="x")

entry_genero = ctk.CTkEntry(janela, placeholder_text="Genero")
entry_genero.pack(pady=10, padx=20, fill="x")

entry_plataforma = ctk.CTkEntry(janela, placeholder_text="Plataforma")
entry_plataforma.pack(pady=10, padx=20, fill="x")

entry_prec_bruto = ctk.CTkEntry(janela, placeholder_text="Preço Bruto")
entry_prec_bruto.pack(pady=10, padx=20, fill="x")

# Estilo padrão dos botões
botao_estilo = {
    "width": 100,
    "height": 30,
    "font": ("Arial", 14),
    "corner_radius": 10,
    "fg_color": "#8A2BE2",  # Roxo
    "hover_color": "#A020F0",  # Roxo mais claro
    "text_color": "white"
}

# Frame de botões
frame_botoes = ctk.CTkFrame(janela, fg_color="transparent")
frame_botoes.pack(pady=20)

btn_cadastrar = ctk.CTkButton(frame_botoes, text="Cadastrar", command=inserir_jogo, **botao_estilo)
btn_cadastrar.grid(row=0, column=0, padx=10, pady=5)

btn_consultar = ctk.CTkButton(frame_botoes, text="Consultar", command=consultar_jogo_id, **botao_estilo)
btn_consultar.grid(row=0, column=1, padx=10, pady=5)

btn_atualizar = ctk.CTkButton(frame_botoes, text="Atualizar", command=atualizar_jogo, **botao_estilo)
btn_atualizar.grid(row=1, column=0, padx=10, pady=5)

btn_deletar = ctk.CTkButton(frame_botoes, text="Deletar", command=deletar_jogo, **botao_estilo)
btn_deletar.grid(row=1, column=1, padx=10, pady=5)

btn_mostrar_todos = ctk.CTkButton(janela, text="Mostrar Todos", command=mostrar_todos_jogos, **botao_estilo)
btn_mostrar_todos.pack(pady=10, padx=20, fill="x")

btn_sair = ctk.CTkButton(janela, text="Sair", command=sair, font= ("Arial", 14, "bold"), fg_color="red", hover_color="dark red")
btn_sair.pack(pady=10, padx=20, fill="x")

# Loop de eventos
janela.mainloop()
