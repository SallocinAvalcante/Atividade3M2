# Autores: Augusto Corrêa da Rocha Neto RGM:11221101575 (Código) Gleydson Akiriro RGM: 11221103498  Nicollas Cavalcante RGM:11221104304 - Estrutura lineares - Atividade 3 M2
# Bibliotecas
import mysql.connector

# Funções
# Função para criar a conexão com o banco de dados
def criar_conexao():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="new_games"
    )

def inserir_estoque(id, descricao, estadoUF, cidade):
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try:
        conexao = criar_conexao() # Abre a conexão com o banco
        cursor = conexao.cursor()

        sql = "INSERT INTO estoque (id, descricao, estadoUF, cidade) VALUES (%s, %s, %s, %s)" # Comando SQL para INSERT
        valores = (id, descricao, estadoUF, cidade)

        cursor.execute(sql, valores) # Executa o comando
        conexao.commit() # Confirma a inserção

        print("Estoque inserido com sucesso!")
        return True, "Estoque inserido com sucesso!" # Retorna Sucesso

    except mysql.connector.Error as erro:
        print(f"Erro ao inserir estoque: {erro}")
        return False, f"Erro ao inserir estoque: {erro}" # Retorna Falso

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close() # Fecha a conexão

def exibir_estoques():
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try:
        conexao = criar_conexao() # Abre a conexão com o banco
        cursor = conexao.cursor()

        sql = "SELECT id, descricao, estadoUF, cidade FROM estoque" # Comando SQL para SELECT de todos os estoques
        cursor.execute(sql)

        resultados = cursor.fetchall() # Cria uma lista e busca por todos os estoques

        return resultados  # retorna a lista
    
    except mysql.connector.Error as erro:
        print(f"Erro ao consultar estoque: {erro}")
        return [] # Garante que sempre retorna uma lista, mesmo no erro

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close() # Fecha a conexão

def consultar_estoque_id(id):
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try:
        conexao = criar_conexao() # Abre conexão com o banco
        cursor = conexao.cursor()

        sql = "SELECT id, descricao, estadoUF, cidade FROM estoque  WHERE id = %s" # Comando SQL para SELECT de um estoque pelo id
        cursor.execute(sql,(id,)) # Criar uma tupla

        estoque = cursor.fetchone() # Busca apenas um estoque que corresponde ao id

        return estoque  # retorna uma tupla ou None

    except mysql.connector.Error as erro:
        print(f"Erro ao consultar cliente: {erro}")
        return None

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close() # Fecha a conexão

def atualizar_estoque(id, descricao=None, estadoUF=None, cidade=None):
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try:
        conexao = criar_conexao()   # Abre conexão
        cursor = conexao.cursor() 

        atualizacoes = [] # Lista para armazenar partes do SQL que vão mudar
        valores = [] # Lista para armazenar os valores correspondentes

        # Para cada campo, adiciona ao SQL e ao valores
        if descricao:
            atualizacoes.append("descricao = %s")
            valores.append(descricao)
        if estadoUF: 
            atualizacoes.append("estadoUF = %s")
            valores.append(estadoUF)
        if cidade:
            atualizacoes.append("cidade = %s")
            valores.append(cidade)

        # Se nada for atualizado, retorna
        if not atualizacoes:
            print("Nenhum campo para atualizar.")
            return

        sql = f"UPDATE estoque SET {', '.join(atualizacoes)} WHERE id = %s" # Comando SQL para UPDATE pelo id
        valores.append(id) 

        cursor.execute(sql, valores) # Executa o comando com os valores
        conexao.commit() # Confirma a atualização

        # Verifica se alguma linha foi alterada
        if cursor.rowcount:
            print("Estoque atualizado com sucesso!")
            return True, "Estoque atualizado com sucesso!" # Retorna Sucesso
        else:
            print("Estoque não encontrado.")

    except mysql.connector.Error as erro:
        print(f"Erro ao atualizar estoque: {erro}")
        return False, f"Erro ao atualizar estoque: {erro}" # Retorna Falso

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close() # Fecha a conexão

def deletar_estoque(id):
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try:
        conexao = criar_conexao() # Abre conexão
        cursor = conexao.cursor()

        sql = "DELETE FROM estoque WHERE id = %s" # Comando SQL para DELETE pelo id
        valor = (id, )

        cursor.execute(sql, valor) # Executa o comando com os valores
        conexao.commit() # Confirma a atualização

        # Verifica se alguma linha foi alterada
        if cursor.rowcount:
            print("Estoque deletado com sucesso!")
            return True, "Estoque deletado com sucesso!" # Retorna Sucesso
        else:
            print("Estoque não encontrado.")

    except mysql.connector.Error as erro:
        print(f"Erro ao deletar estoque: {erro}")
        return False, f"Erro ao deletar estoque: {erro}" # Retorna Falso

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close() # Fecha a conexão
