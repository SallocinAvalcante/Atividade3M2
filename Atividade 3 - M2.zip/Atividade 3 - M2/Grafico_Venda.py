# Autores: Augusto Corrêa da Rocha Neto RGM:11221101575 Gleydson Akiriro RGM: 11221103498  Nicollas Cavalcante RGM:11221104304 (Código)
# Estrutura lineares - Atividade 3 M2

import mysql.connector
import matplotlib.pyplot as mplt

# Conexão com o banco de dados
def criar_conexao():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="new_games"
    )

# Consulta e geração do gráfico
def gerar_grafico_vendas():
    conexao = criar_conexao() ## conectando no db
    cursor = conexao.cursor()

    # Consulta SQL: nomes dos jogos e soma das quantidades vendidas
    query = """
        SELECT j.nome, SUM(v.quant) as total_vendido
        FROM venda v
        JOIN jogos j ON v.fk_id_jog = j.id
        GROUP BY j.nome
        ORDER BY total_vendido DESC;
    """
    
    cursor.execute(query) ##Executa query, Query - consulta, array - requsisição
    resultados = cursor.fetchall()

    jogos = [linha[0] for linha in resultados]
    vendas = [linha[1] for linha in resultados]

    # Estilo de fundo escuro
    mplt.style.use('dark_background')

    # Gráfico
    mplt.figure(figsize=(15, 6))
    bars = mplt.barh(jogos, vendas, color='#8A2BE2')
    mplt.xlabel("Vendas")
    mplt.title("Gráfico de Vendas")

    # Adiciona valores dentro das barras
    for bar, value in zip(bars, vendas):
        largura = bar.get_width()
        mplt.text(largura - (largura * 0.1),   # Posição x: 10% antes do final
                  bar.get_y() + bar.get_height() / 2,  # Posição y: meio da barra
                  str(value), 
                  va='center', 
                  ha='right', 
                  color='white', 
                  fontweight='bold')

    mplt.tight_layout()
    mplt.show()

    cursor.close()
    conexao.close()

# Executar
gerar_grafico_vendas()
