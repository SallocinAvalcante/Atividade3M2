# Autores: Augusto Corrêa da Rocha Neto RGM:11221101575 Gleydson Akiriro RGM: 11221103498 (Código) Nicollas Cavalcante RGM:11221104304 - Estrutura lineares - Atividade 3 M2
#Bibliotecas
import numpy as np
import networkx as nx
import matplotlib.pyplot as mplot
# Coordenadas/nós da lista - Dicionário
lista = {
"Loja Matriz \n SÃO PAULO - SP ": ["Loja no \n Estado da Bahia","Lojas no \n Estado de São Paulo",
                                   "Lojas no \n Estado de Minas Gerais","Loja no \n Estado do Rio de Janeiro"],
"Loja no \n Estado da Bahia": ["Loja Filial \n VITÓRIA-BA "],
"Lojas no \n Estado de São Paulo": ["Loja Filial \n TATUAPÉ-SP ","Loja Filial \n PINHEIROS-SP "],
"Lojas no \n Estado de Minas Gerais": ["Loja Filial \n BELO HORIZONTE-MG ","Loja Filial \n CAPITÓLIO-MG "],
"Loja no \n Estado do Rio de Janeiro": ["Loja Filial \n NITERÓI-RJ "],
}

# Estilo de fundo escuro
mplot.style.use('dark_background')

# Criação do objeto Grafo
G = nx.Graph()

# Adição de Arestas
for (nos, conjuntos) in lista.items():
    for conjunto in conjuntos:
        G.add_edge(nos, conjunto)

# Desenhar Grafo
mplot.figure(figsize=(8, 8))
pos = nx.spring_layout(G)  # Cria um espaço mais harmonioso dos nós

# Cor roxo claro: #C084FC
nx.draw(
    G, pos, 
    with_labels=True, 
    node_color="#C084FC",   # <- Cor roxo claro
    edge_color="gray",
    node_size=1000, 
    font_size=12
)

#Exibe do Grafo
mplot.show()