# Autores: Augusto Corrêa da Rocha Neto RGM:11221101575 (Código) Gleydson Akiriro RGM: 11221103498  Nicollas Cavalcante RGM:11221104304 - Estrutura lineares - Atividade 3 M2
#Bibliotecas
import mysql.connector

#Funções
# Função para criar a conexão com o banco de dados
def criar_conexao():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="new_games"
    )

def inserir_cliente(cpf, nome, email, senha, endereco):
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try:
        conexao = criar_conexao() # Abre conexão com o banco
        cursor = conexao.cursor()

        sql = "INSERT INTO clientes (cpf, nome, email, senha, endereco) VALUES (%s, %s, %s, %s, %s)" # Comando SQL para INSERT
        valores = (cpf, nome, email, senha, endereco)

        cursor.execute(sql, valores) # Executa o comando
        conexao.commit() # Confirma a inserção

        print("Cliente inserido com sucesso!")
        return True, "Cliente inserido com sucesso!" # Retorna Sucesso

    except mysql.connector.Error as erro:
        print(f"Erro ao inserir: {erro}")
        return False, f"Erro ao inserir: {erro}" # Retorna Falso

    finally:
        if conexao and conexao.is_connected():
            cursor.close()  
            conexao.close() # Fecha a conexão

def consultar_cliente_cpf(cpf):
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try:
        conexao = criar_conexao() # Abre conexão com o banco
        cursor = conexao.cursor()

        sql = "SELECT cpf, nome, email, endereco FROM clientes  WHERE cpf = %s" # Comando SQL para SELECT de um cliente pelo cpf
        cursor.execute(sql,(cpf,)) # Criar uma tupla

        cliente = cursor.fetchone() # Busca apenas um cliente que corresponde ao CPF

        return cliente  # retorna uma tupla ou None

    except mysql.connector.Error as erro:
        print(f"Erro ao consultar cliente: {erro}")
        return None

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close() # Fecha a conexão

def exibir_clientes():
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try:
        conexao = criar_conexao() # Abre conexão com o banco
        cursor = conexao.cursor()

        sql = "SELECT cpf, nome, email, senha, endereco FROM clientes" # Comando SQL para SELECT de todos os clientes
        cursor.execute(sql)

        resultados = cursor.fetchall() # Cria uma lista e busca por todos os clientes

        return resultados  # retorna a lista

    except mysql.connector.Error as erro:
        print(f"Erro ao consultar: {erro}")
        return [] # Garante que sempre retorna uma lista, mesmo no erro

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close() # Fecha a conexão

def atualizar_cliente(cpf, nome=None, email=None, senha=None, endereco=None):
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try:
        conexao = criar_conexao()
        cursor = conexao.cursor()

        atualizacoes = []   # Lista para armazenar partes do SQL que vão mudar
        valores = [] # Lista para armazenar os valores correspondentes

         # Para cada campo, adiciona ao SQL e ao valores
        if nome:
            atualizacoes.append("nome = %s")
            valores.append(nome)
        if email:
            atualizacoes.append("email = %s")
            valores.append(email)
        if senha:
            atualizacoes.append("senha = %s")
            valores.append(senha)
        if endereco:
            atualizacoes.append("endereco = %s")
            valores.append(endereco)

        # Se não tiver nenhum campo para atualizar, a função termina
        if not atualizacoes:
            print("Nenhum campo para atualizar.")
            return

        sql = f"UPDATE clientes SET {', '.join(atualizacoes)} WHERE cpf = %s" # Comando SQL para UPDATE pelo cpf
        valores.append(cpf)

        cursor.execute(sql, valores) # Executa o comando com os valores
        conexao.commit() # Confirma a atualização

        # Verifica se alguma linha foi alterada
        if cursor.rowcount:
            print("Cliente atualizado com sucesso!")
            return True, "Cliente atualizado com sucesso!" # Retorna Sucesso
        else:
            print("Cliente não encontrado.")

    except mysql.connector.Error as erro:
        print(f"Erro ao atualizar: {erro}")
        return False, f"Erro ao atualizar: {erro}" # Retorna Falso

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close()

def deletar_cliente(cpf):
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try:
        conexao = criar_conexao() # Abre conexão
        cursor = conexao.cursor() 

        sql = "DELETE FROM clientes WHERE cpf = %s" # Comando SQL para DELETE pelo cpf
        valor = (cpf, )

        cursor.execute(sql, valor) # Executa o comando
        conexao.commit() # Confirma a exclusão

        # Verifica se alguma linha foi alterada
        if cursor.rowcount:
            print("Cliente deletado com sucesso!")
            return True, "Cliente deletado com sucesso!" # Retorna Sucesso
        else:
            print("Cliente não encontrado.")

    except mysql.connector.Error as erro:
        print(f"Erro ao deletar: {erro}")
        return False, f"Erro ao atualizar: {erro}" # Retorna Falso

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close() # Fecha a conexão

