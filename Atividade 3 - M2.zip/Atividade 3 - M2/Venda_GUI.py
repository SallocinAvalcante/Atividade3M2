# Autores: Augusto Corrêa da Rocha Neto RGM:11221101575 Gleydson Akiriro RGM: 11221103498  Nicollas Cavalcante RGM:11221104304 (Código)- Estrutura lineares - Atividade 3 M2
import customtkinter as ctk
from CTkMessagebox import CTkMessagebox
from PIL import Image, ImageTk
import venda  # Importa as funções de venda.py
import subprocess # Biblioteca para abrir outras janelas de arquivos python

ctk.set_appearance_mode("dark")  # Modo escuro
ctk.set_default_color_theme("dark-blue")  # Tema azul

# Função para cadastrar venda
def inserir_venda():
    pk_id = entry_pk_id.get()
    nota_fiscal = entry_nota_fiscal.get()
    preco_v = entry_preco_v.get()
    quant = entry_quant.get()
    data_E = entry_data_E.get()
    fk_id_cli = entry_fk_id_cli.get()
    fk_id_jog = entry_fk_id_jog.get()
    fk_id_est = entry_fk_id_est.get()

    sucesso, mensagem = venda.inserir_venda(pk_id, nota_fiscal, preco_v, quant, data_E, fk_id_cli, fk_id_jog, fk_id_est)

    if sucesso:
        CTkMessagebox(title="Sucesso", message=mensagem, icon="check", button_color="#8A2BE2", button_hover_color="#A020F0")
        limpar_tela()
    else:
        CTkMessagebox(title="Erro", message=mensagem, icon="cancel", button_color="#8A2BE2", button_hover_color="#A020F0")

# Função para consultar venda
def consultar_venda_id():
    pk_id = entry_pk_id.get()

    if not pk_id:
        CTkMessagebox(title="Consulta", message="Por favor, informe o ID para consultar.", icon="warning", button_color="#8A2BE2", button_hover_color="#A020F0")
        return
    v = venda.consultar_venda_id(pk_id)

    if v:
        entry_nota_fiscal.delete(0, ctk.END)
        entry_nota_fiscal.insert(0, str(v[0]))

        entry_preco_v.delete(0, ctk.END)
        entry_preco_v.insert(0, str(v[1]))

        entry_quant.delete(0, ctk.END)
        entry_quant.insert(0, str(v[2]))

        entry_data_E.delete(0, ctk.END)
        entry_data_E.insert(0, str(v[3]))

        entry_fk_id_cli.delete(0, ctk.END)
        entry_fk_id_cli.insert(0, str(v[4]))

        entry_fk_id_jog.delete(0, ctk.END)
        entry_fk_id_jog.insert(0, str(v[5]))

        entry_fk_id_est.delete(0, ctk.END)
        entry_fk_id_est.insert(0, str(v[6]))

        CTkMessagebox(title="Consulta", message=f"Venda encontrada:\nNota Fiscal: {v[1]}\nPreço Final: {v[2]}\nQuantidade: {v[3]}\nData: {v[4]}",
                      icon="check", button_color="#8A2BE2",button_hover_color="#A020F0")
    else:
        CTkMessagebox(title="Consulta", message="Venda não encontrada.", icon="warning")

# Função para mostrar todas as vendas
def mostrar_todas_vendas():
    vendas_lista = venda.exibir_vendas()

    if not vendas_lista:
        CTkMessagebox(title="Consulta", message="Nenhuma venda encontrada.", icon="warning", button_color="#8A2BE2", button_hover_color="#A020F0")
        return
    v_str = "ID - Nota Fiscal - Preço Final - Quantidade - Data - ClienteID - JogoID - EstoqueID\n\n"
    for v in vendas_lista:
        v_str += f"\n{v[0]} - {v[1]} - {v[2]} - {v[3]} - {v[4]} - {v[5]} - {v[6]} - {v[7]}\n"

    CTkMessagebox(title="Todos as Vendas", message=v_str, icon="Icone_NewGames.ico", width=800, height=300,
                   button_color="#8A2BE2", button_hover_color="#A020F0")

# Função para atualizar venda pelo id
def atualizar_venda():
    pk_id = entry_pk_id.get()
    nota_fiscal = entry_nota_fiscal.get()
    preco_v = entry_preco_v.get()
    quant = entry_quant.get()
    data_E = entry_data_E.get()
    fk_id_cli = entry_fk_id_cli.get()
    fk_id_jog = entry_fk_id_jog.get()
    fk_id_est = entry_fk_id_est.get()

    sucesso, mensagem = venda.atualizar_venda(pk_id, nota_fiscal, preco_v, quant, data_E, fk_id_cli, fk_id_jog, fk_id_est)

    if sucesso:
        CTkMessagebox(title="Sucesso", message=mensagem, icon="check", button_color="#8A2BE2", button_hover_color="#A020F0")
        limpar_tela()
    else:
        CTkMessagebox(title="Erro", message=mensagem, icon="cancel", button_color="#8A2BE2", button_hover_color="#A020F0")

# Função para deletar venda
def deletar_venda():
    pk_id = entry_pk_id.get()

    sucesso, mensagem = venda.deletar_venda(pk_id)

    if sucesso:
        CTkMessagebox(title="Sucesso", message=mensagem, icon="check", button_color="#8A2BE2", button_hover_color="#A020F0")
        limpar_tela()
    else:
        CTkMessagebox(title="Erro", message=mensagem, icon="cancel", button_color="#8A2BE2", button_hover_color="#A020F0")

# Função de limpar a tela
def limpar_tela():
    entry_pk_id.delete(0, ctk.END)
    entry_nota_fiscal.delete(0, ctk.END)
    entry_preco_v.delete(0, ctk.END)
    entry_quant.delete(0, ctk.END)
    entry_data_E.delete(0, ctk.END)
    entry_fk_id_cli.delete(0, ctk.END)
    entry_fk_id_jog.delete(0, ctk.END)
    entry_fk_id_est.delete(0, ctk.END)
    entry_pk_id.focus()

# Função de sair
def sair():
    opcao = CTkMessagebox(title="Sair", message="Deseja sair?", icon="question", option_2="Sim", option_1="Não", button_color="#8A2BE2", button_hover_color="#A020F0")
    if opcao.get() == "Sim":
        janela.destroy()

def abrir_grafico_vendas():
    CTkMessagebox(title="Gráfico de Vendas", message= "Abrindo gráficos de vendas...", button_color="#8A2BE2", button_hover_color="#A020F0")
    subprocess.Popen(["python", "Grafico_Venda.py"])

# Janela principal
janela = ctk.CTk()
janela.title("Cadastro de Vendas")
janela.geometry("500x650")
janela.resizable(False, False)
janela.iconbitmap("Icone_NewGames.ico")

# Imagem no canto superior esquerdo
imagem = Image.open("Logo_NewGames.png")
imagem = imagem.resize((200, 85))  
imagem_tk = ImageTk.PhotoImage(imagem)

frame_topo = ctk.CTkFrame(janela, fg_color="transparent")
frame_topo.pack(pady=10, anchor='w')

label_imagem = ctk.CTkLabel(frame_topo, image=imagem_tk, text="")
label_imagem.pack(side="left", padx=10)

# Frame para organizar os campos em duas colunas
frame_campos = ctk.CTkFrame(janela, fg_color="transparent")
frame_campos.pack(pady=20, padx=20)

# Entradas
entry_pk_id = ctk.CTkEntry(frame_campos, placeholder_text="ID")
entry_pk_id.grid(row=0, column=0, padx=(5, 10), pady=10, sticky="w")

entry_nota_fiscal = ctk.CTkEntry(frame_campos, placeholder_text="Nota Fiscal")
entry_nota_fiscal.grid(row=0, column=1, padx=(5, 10), pady=10, sticky="w")

entry_preco_v = ctk.CTkEntry(frame_campos, placeholder_text="Preço Final")
entry_preco_v.grid(row=1, column=0, padx=(5, 10), pady=10, sticky="w")

entry_quant = ctk.CTkEntry(frame_campos, placeholder_text="Quantidade")
entry_quant.grid(row=1, column=1, padx=(5, 10), pady=10, sticky="w")

entry_data_E = ctk.CTkEntry(frame_campos, placeholder_text="Data (yyyy-mm-dd)")
entry_data_E.grid(row=2, column=0, padx=(5, 10), pady=10, sticky="w")

entry_fk_id_cli = ctk.CTkEntry(frame_campos, placeholder_text="CPF Cliente")
entry_fk_id_cli.grid(row=2, column=1, padx=(5, 10), pady=10, sticky="w")

entry_fk_id_jog = ctk.CTkEntry(frame_campos, placeholder_text="ID Jogo")
entry_fk_id_jog.grid(row=3, column=0, padx=(5, 10), pady=10, sticky="w")

entry_fk_id_est = ctk.CTkEntry(frame_campos, placeholder_text="ID Estoque")
entry_fk_id_est.grid(row=3, column=1, padx=(5, 10), pady=10, sticky="w")

# Estilo padrão dos botões
botao_estilo = {
    "width": 100,
    "height": 30,
    "font": ("Arial", 14),
    "corner_radius": 10,
    "fg_color": "#8A2BE2",
    "hover_color": "#A020F0",
    "text_color": "white"
}

# Frame para botões
frame_botoes = ctk.CTkFrame(janela, fg_color="transparent")
frame_botoes.pack(pady=20)

btn_cadastrar = ctk.CTkButton(frame_botoes, text="Cadastrar", command=inserir_venda, **botao_estilo)
btn_cadastrar.grid(row=0, column=0, padx=10, pady=5)

btn_consultar = ctk.CTkButton(frame_botoes, text="Consultar", command=consultar_venda_id, **botao_estilo)
btn_consultar.grid(row=0, column=1, padx=10, pady=5)

btn_atualizar = ctk.CTkButton(frame_botoes, text="Atualizar", command=atualizar_venda, **botao_estilo)
btn_atualizar.grid(row=1, column=0, padx=10, pady=5)

btn_deletar = ctk.CTkButton(frame_botoes, text="Deletar", command=deletar_venda, **botao_estilo)
btn_deletar.grid(row=1, column=1, padx=10, pady=5)

btn_mostrar_todos = ctk.CTkButton(janela, text="Mostrar Todas", command=mostrar_todas_vendas, **botao_estilo)
btn_mostrar_todos.pack(pady=10, padx=20, fill="x")

btn_grafico_vendas = ctk.CTkButton(janela, text="📈 Gráfico de Vendas", command=abrir_grafico_vendas, **botao_estilo)
btn_grafico_vendas.pack(pady=10, padx=20, fill="x")

btn_sair = ctk.CTkButton(janela, text="Sair", command=sair, fg_color="red", hover_color="dark red")
btn_sair.pack(pady=10, padx=20, fill="x")

janela.mainloop()