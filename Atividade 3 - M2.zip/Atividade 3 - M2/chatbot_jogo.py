# Autores: Augusto Corrêa da Rocha Neto RGM:11221101575 Gleydson Akiriro RGM: 11221103498 (Código)  Nicollas Cavalcante RGM:11221104304 - Estrutura lineares - Atividade 3 M2
import customtkinter as ctk
from CTkMessagebox import CTkMessagebox
from datetime import datetime
from PIL import Image, ImageTk
import google.generativeai as genai

# Configuração da API Gemini
genai.configure(api_key="AIzaSyBMk5LiBLDdXT_yvYI0zqJEVjL1tg8oOjQ")
modelo = genai.GenerativeModel('gemini-2.0-flash-thinking-exp-1219')
chat = modelo.start_chat(history=[])

# Lista de palavras-chave relacionadas a jogos
palavras_chave = [
    "jogo", "games", "console", "videogame", "FPS", "RPG", 
    "Nintendo", "PlayStation", "Xbox", "Steam", "PC", "mobile",
    "gamer", "esports", "personagem", "história do jogo", "lançamento",
    "multiplayer", "campanha", "gameplay", "ranking", "level", "video games", "Games",
    "game", "jogos", "video game", "Video Games"
]

# Função de verificação de contexto
def mensagem_relacionada_a_jogos(mensagem):
    mensagem = mensagem.lower()
    return any(palavra in mensagem for palavra in palavras_chave)

# Função do chatbot
def chatbot(mensagem):
    try:
        respostas = chat.send_message(mensagem)
        return f"{respostas.text}"
    except Exception as e:
        return f"⚠️ Erro ao se comunicar com o GameBot: {e}"

# Função de envio da mensagem
def enviar_mensagem():
    mensagem_usuario = entrada_usuario.get()
    if not mensagem_usuario.strip():
        return
    if not mensagem_relacionada_a_jogos(mensagem_usuario):
        resposta_chatbot = "⚠️ O GameBot só responde perguntas relacionadas ao universo dos jogos. Por favor, reformule sua pergunta!"
    else:
        resposta_chatbot = chatbot(mensagem_usuario)

    caixa_texto.insert(ctk.END, f"\n🎮 Usuário Gamer: {mensagem_usuario}\n", "usuario")
    caixa_texto.insert(ctk.END, f"🤖 GameBot: {resposta_chatbot}\n", "chatbot")
    entrada_usuario.delete(0, ctk.END)

# Estilo do aplicativo
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

# Janela principal
janela = ctk.CTk()
janela.title("GameBot - Assistente Virtual de Jogos")
janela.geometry("550x680+500+50")
janela.resizable(False, False)
janela.iconbitmap("Icone_NewGames.ico")

# Imagem no canto superior esquerdo
imagem = Image.open("Logo_NewGames.png")
imagem = imagem.resize((200, 85))  
imagem_tk = ImageTk.PhotoImage(imagem)

frame_topo = ctk.CTkFrame(janela, fg_color="transparent")
frame_topo.pack(pady=10, anchor='w')

label_imagem = ctk.CTkLabel(frame_topo, image=imagem_tk, text="")
label_imagem.pack(side="left", padx=10)

# Caixa de texto do chat
caixa_texto = ctk.CTkTextbox(janela, wrap=ctk.WORD, width=440, height=500, font=("Consolas", 12))
caixa_texto.pack(pady=(10, 0))

# Estilos para usuário e chatbot
caixa_texto.tag_config("usuario", foreground="#c47bff", justify="left")
caixa_texto.tag_config("chatbot", foreground="white", justify="left")

# Mensagem inicial
data_hora = datetime.now().strftime("%d/%m/%Y %H:%M")
boas_vindas = f"[{data_hora}]\n🤖 GameBot: Boas-vindas ao universo Next Games, Usuário Gamer! Em que posso te ajudar hoje?\n"
caixa_texto.insert(ctk.END, boas_vindas, "chatbot")

# Área de entrada
frame_entrada = ctk.CTkFrame(janela, fg_color="#1d1d1d")
frame_entrada.pack(pady=10)

# Rótulo do usuário fixo
label_id = ctk.CTkLabel(frame_entrada, text="Usuário Gamer", font=("Orbitron", 13, "bold"), text_color="white")
label_id.grid(row=0, column=0, padx=5)

# Campo de entrada
entrada_usuario = ctk.CTkEntry(frame_entrada, width=240, font=("Consolas", 12), text_color="white")
entrada_usuario.grid(row=0, column=1, padx=5)

#Botão enviar 
botao_enviar = ctk.CTkButton(frame_entrada, text = "Enviar", font=("Helvetica", 12, "bold"), command = enviar_mensagem, fg_color="#8A2BE2", hover_color="#A020F0")
botao_enviar.grid(row=0, column=2, padx=5, pady=10)


# Loop principal
janela.mainloop()
