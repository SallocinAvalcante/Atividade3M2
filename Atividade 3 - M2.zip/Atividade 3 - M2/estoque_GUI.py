# Autores: Augusto Corrêa da Rocha Neto RGM:11221101575 (Código) Gleydson Akiriro RGM: 11221103498  Nicollas Cavalcante RGM:11221104304 - Estrutura lineares - Atividade 3 M2
import customtkinter as ctk
from CTkMessagebox import CTkMessagebox
from PIL import Image, ImageTk
import estoque  # Importa as funções de estoque.py
import subprocess # Biblioteca para abrir outras janelas de arquivos python

# Função para cadastrar estoque
def inserir_estoque():
    id = entry_id.get()
    descricao = entry_descricao.get()
    estadoUF = entry_estado.get()
    cidade = entry_cidade.get()

    sucesso, mensagem = estoque.inserir_estoque(id, descricao, estadoUF, cidade) # Se tiver sucesso, insere os dados

    if sucesso:
        CTkMessagebox(title="Sucesso", message=mensagem, icon="check", button_color="#8A2BE2", button_hover_color="#A020F0")
        limpar_tela()
    else:
        CTkMessagebox(title="Erro", message=mensagem, icon="cancel", button_color="#8A2BE2", button_hover_color="#A020F0")

# Função para consultar estoque pelo id
def consultar_estoque_id():
    id = entry_id.get()

    if not id: # Se o campo estiver nulo/errado
        CTkMessagebox(title="Consulta", message="Por favor, informe o ID para consultar.", icon="warning", button_color="#8A2BE2", button_hover_color="#A020F0")
        return
    
    estoques = estoque.consultar_estoque_id(id)

    if estoques:
        # Preencher os campos
        entry_descricao.delete(0, ctk.END)
        entry_descricao.insert(0, estoques[1])

        entry_estado.delete(0, ctk.END)
        entry_estado.insert(0, estoques[2])

        entry_cidade.delete(0, ctk.END)
        entry_cidade.insert(0, estoques[3])

        CTkMessagebox(title="Consulta", message=f"Estoque encontrado:\nDescrição: {estoques[1]}\nEstado (UF): {estoques[2]}\nCidade: {estoques[3]}",
                      icon="check", button_color="#8A2BE2",button_hover_color="#A020F0")
    else:
        CTkMessagebox(title="Consulta", message="Estoque não encontrado.", icon="warning")

# Função para mostrar todos os estoque
def mostrar_todos_estoques():
    estoques_lista = estoque.exibir_estoques()

    if not estoques_lista:
        CTkMessagebox(title="Consulta", message="Nenhum estoque encontrado.", icon="warning", button_color="#8A2BE2", button_hover_color="#A020F0")
        return
    estoques_str = "ID - Descrição - Estado (UF) - Cidade\n\n"
    for estoques in estoques_lista:
        estoques_str += f"\n{estoques[0]} - {estoques[1]} - {estoques[2]} - {estoques[3]}\n"
    CTkMessagebox(title="Todos os Estoques", message=estoques_str, icon="Icone_NewGames.ico", width=600, height=300,
                   button_color="#8A2BE2", button_hover_color="#A020F0")

# Função para atualizar estoque
def atualizar_estoque():
    id = entry_id.get()
    descricao = entry_descricao.get()
    estadoUF = entry_estado.get()
    cidade = entry_cidade.get()

    sucesso, mensagem = estoque.atualizar_estoque(id, descricao, estadoUF, cidade) # Se tiver sucesso, altera os dados

    if sucesso:
        CTkMessagebox(title="Sucesso", message=mensagem, icon="check", button_color="#8A2BE2", button_hover_color="#A020F0") # Mostra mensagem de sucesso
        limpar_tela()
    else:
        CTkMessagebox(title="Erro", message=mensagem, icon="cancel", button_color="#8A2BE2", button_hover_color="#A020F0")

# Função para deletar estoque
def deletar_estoque():
    id = entry_id.get()

    sucesso, mensagem = estoque.deletar_estoque(id)

    if sucesso:
        CTkMessagebox(title="Sucesso", message=mensagem, icon="check", button_color="#8A2BE2", button_hover_color="#A020F0")
        limpar_tela()
    else:
        CTkMessagebox(title="Erro", message=mensagem, icon="cancel", button_color="#8A2BE2", button_hover_color="#A020F0")

#Função de Limpar a tela
def limpar_tela():
        entry_id.delete(0,ctk.END)
        entry_descricao.delete(0,ctk.END)
        entry_estado.delete(0,ctk.END)
        entry_cidade.delete(0,ctk.END)
        entry_id.focus()

# Função de sair da janela
def sair():
    opcao = CTkMessagebox(title="Sair", message="Deseja sair?", icon="question", option_2="Sim", option_1="Não", button_color="#8A2BE2", button_hover_color="#A020F0")
    if opcao.get() == "Sim":
        janela.destroy()

# Janela principal
janela = ctk.CTk()
janela.title("Cadastro de Estoque")
janela.geometry("400x600")
janela.resizable(False, False)
janela.iconbitmap("Icone_NewGames.ico")

# Imagem no canto superior esquerdo (cabeçalho)
imagem = Image.open("Logo_NewGames.png")
imagem = imagem.resize((200, 85))  # Ajustar o tamanho da imagem
imagem_tk = ImageTk.PhotoImage(imagem)

# Frame do cabeçalho
frame_topo = ctk.CTkFrame(janela, fg_color="transparent")
frame_topo.pack(pady=10, anchor='w')  # Alinha à esquerda

label_imagem = ctk.CTkLabel(frame_topo, image=imagem_tk, text="")
label_imagem.pack(side="left", padx=10)

# Campos de entrada
entry_id = ctk.CTkEntry(janela, placeholder_text="ID")
entry_id.pack(pady=10, padx=20, fill="x")

entry_descricao = ctk.CTkEntry(janela, placeholder_text="Descrição")
entry_descricao.pack(pady=10, padx=20, fill="x")

entry_estado = ctk.CTkEntry(janela, placeholder_text="Estado (UF)")
entry_estado.pack(pady=10, padx=20, fill="x")

entry_cidade = ctk.CTkEntry(janela, placeholder_text="Cidade")
entry_cidade.pack(pady=10, padx=20, fill="x")

# Estilo padrão dos botões
botao_estilo = {
    "width": 100,
    "height": 30,
    "font": ("Arial", 14),
    "corner_radius": 10,
    "fg_color": "#8A2BE2",  # Roxo
    "hover_color": "#A020F0",  # Roxo mais claro
    "text_color": "white"
}

# Botões
frame_botoes = ctk.CTkFrame(janela, fg_color="transparent")
frame_botoes.pack(pady=20)

btn_cadastrar = ctk.CTkButton(frame_botoes, text="Cadastrar", command=inserir_estoque, **botao_estilo)
btn_cadastrar.grid(row=0, column=0, padx=10, pady=5)

btn_consultar = ctk.CTkButton(frame_botoes, text="Consultar", command=consultar_estoque_id, **botao_estilo)
btn_consultar.grid(row=0, column=1, padx=10, pady=5)

btn_atualizar = ctk.CTkButton(frame_botoes, text="Atualizar", command=atualizar_estoque, **botao_estilo)
btn_atualizar.grid(row=1, column=0, padx=10, pady=5)

btn_deletar = ctk.CTkButton(frame_botoes, text="Deletar", command=deletar_estoque, **botao_estilo)
btn_deletar.grid(row=1, column=1, padx=10, pady=5)

btn_mostrar_todos = ctk.CTkButton(janela, text="Mostrar Todos", command=mostrar_todos_estoques, **botao_estilo)
btn_mostrar_todos.pack(pady=10, padx=20, fill="x")

btn_sair = ctk.CTkButton(janela, text="Sair", command=sair, fg_color="red", hover_color="dark red")
btn_sair.pack(pady=10, padx=20, fill="x")

# Loop da interface
janela.mainloop()