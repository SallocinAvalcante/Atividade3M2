# Autores: Augusto Corrêa da Rocha Neto RGM:11221101575 Gleydson Akiriro RGM: 11221103498  Nicollas Cavalcante RGM:11221104304 (Código)- Estrutura lineares - Atividade 3 M2
import customtkinter as ctk
from CTkMessagebox import CTkMessagebox
import csv
import subprocess
from PIL import Image, ImageTk

 # Função para abrir outras janelas
def abrir_menu():
    CTkMessagebox(title="Login", message= "Login realizado com sucesso!", button_color="#8A2BE2", button_hover_color="#A020F0")
    janela.destroy()  # Fecha a janela atual
    subprocess.run(["python", "Menu_New_Games.py"])  # Executa o outro script
    
# Função para ler os dados do CSV e verificar o login
def verificar_login():
    usuario = entrada_usuario.get()
    senha = entrada_senha.get()
    encontrado = False
 
    try:
        with open("usuarios.csv", newline="", encoding="utf-8") as arquivo_csv:
            leitor = csv.DictReader(arquivo_csv)
            for linha in leitor:
                if linha["usuario"] == usuario and linha["senha"] == senha:
                    encontrado = True
                    break
 
        if encontrado:
            CTkMessagebox(title="Login", message= "Login realizado com sucesso!", icon="check", button_color="#8A2BE2", button_hover_color="#A020F0")
            abrir_menu()
        else:
            CTkMessagebox(title="Erro", message= "Usuário ou senha incorretos. tente outra vez", icon="cancel", button_color="#8A2BE2", button_hover_color="#A020F0")
 
    except FileNotFoundError:
        CTkMessagebox(title="Erro", message= "Arquivo de usuários não encontrado.", icon="cancel", button_color="#8A2BE2", button_hover_color="#A020F0")
 
# Configurações do tema
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

# Criação de Janela
janela = ctk.CTk()
janela.title("New Games - Login")
janela.geometry("400x400+100+200")
janela.resizable(False, False)  # Janela com tamanho fixo
janela.iconbitmap("Icone_NewGames.ico")

# Frame principal com fundo transparente sobre a imagem
frame = ctk.CTkFrame(janela, fg_color="transparent")
frame.place(relx=0.5, rely=0.5, anchor="center")  # centraliza no meio da tela
 
# Carregando a imagem
logo_image = ctk.CTkImage(
    light_image=Image.open("Logo_NewGames.png"), 
    dark_image=Image.open("Logo_NewGames.png"), 
    size=(300, 100)  # ajuste do tamanho da imagem
)

# Label com a imagem
logo_label = ctk.CTkLabel(janela, image=logo_image, text="")  # text vazio para não mostrar texto
logo_label.pack(pady=(30, 10))
 
# Subtítulo
subtitulo = ctk.CTkLabel(
    frame,
    text="FAÇA LOGIN PARA CONTINUAR",
    font=("Arial", 14, "bold"),
    text_color="white"
)
subtitulo.pack(pady=(0, 20))
 
# Campo de usuário
entrada_usuario = ctk.CTkEntry(
    frame,
    width=250,
    height=40,
    placeholder_text="Usuário",
    corner_radius=10
)
entrada_usuario.pack(pady=10)
 
# Campo de senha
entrada_senha = ctk.CTkEntry(
    frame,
    width=250,
    height=40,
    placeholder_text="Senha",
    corner_radius=10,
    show="*"
)
entrada_senha.pack(pady=10)
 
# Botão de login
botao_login = ctk.CTkButton(
    frame,
    text="Entrar",
    command=verificar_login,
    width=250,
    height=40,
    fg_color="#A020F0",
    hover_color="#BA55D3",
    corner_radius=10,
    font=("Arial", 14, "bold")
)
botao_login.pack(pady=20)
 
# Rodapé
rodape = ctk.CTkLabel(
    janela,
    text="New Games © 2025",
    font=("Arial", 10)
)
rodape.place(relx=0.5, rely=0.95, anchor="center")  # posiciona próximo do rodapé
 
# Loop de Interface
janela.mainloop()