# Autores: Augusto Corrêa da Rocha Neto RGM:11221101575 (Código) Gleydson Akiriro RGM: 11221103498  Nicollas Cavalcante RGM:11221104304 - Estrutura lineares - Atividade 3 M2
# Bibliotecas
import mysql.connector

# Funções

# Função para criar a conexão com o banco de dados
def criar_conexao():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="new_games"
    )

def inserir_venda(pk_id, nota_fiscal, preco_v, quant, data_E, fk_id_cli, fk_id_jog, fk_id_est):
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try:
        conexao = criar_conexao() # Abre a conexão com o banco
        cursor = conexao.cursor()

        sql = "INSERT INTO venda (pk_id, nota_fiscal, preco_v, quant, data_E, fk_id_cli, fk_id_jog, fk_id_est) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)" # Comando SQL para INSERT
        valores = (pk_id, nota_fiscal, preco_v, quant, data_E, fk_id_cli, fk_id_jog, fk_id_est)

        cursor.execute(sql, valores) # Executa o comando
        conexao.commit() # Confirma a inserção

        print("Venda inserida com sucesso!")
        return True, "Venda inserida com sucesso!" # Retorna Sucesso

    except mysql.connector.Error as erro:
        print(f"Erro ao inserir venda: {erro}")
        return False, f"Erro ao inserir: {erro}" # Retorna Falso

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close() # Fecha a conexão

def consultar_venda_id(pk_id):
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try:
        conexao = criar_conexao() # Abre conexão com o banco
        cursor = conexao.cursor()

        sql = "SELECT nota_fiscal, preco_v, quant, data_E, fk_id_cli, fk_id_jog, fk_id_est FROM venda WHERE pk_id = %s" # Comando SQL para SELECT de um estoque pelo pk_id
        cursor.execute(sql,(pk_id,)) # Criar uma tupla

        estoque = cursor.fetchone() # Busca apenas um estoque que corresponde ao pk_id

        return estoque  # retorna uma tupla ou None

    except mysql.connector.Error as erro:
        print(f"Erro ao consultar venda: {erro}")
        return None

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close() # Fecha a conexão

def exibir_vendas():
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try:
        conexao = criar_conexao() # Abre a conexão com o banco
        cursor = conexao.cursor()

        sql = "SELECT pk_id, nota_fiscal, preco_v, quant, data_E, fk_id_cli, fk_id_jog, fk_id_est FROM venda" # Comando SQL para SELECT de todas as venda
        cursor.execute(sql)

        resultados = cursor.fetchall() # Cria uma lista e busca por todos as venda

        return resultados  # retorna a lista
        
    except mysql.connector.Error as erro:
        print(f"Erro ao consultar venda: {erro}")
        return [] # Garante que sempre retorna uma lista, mesmo no erro

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close() # Fecha a conexão

def atualizar_venda(pk_id, nota_fiscal=None, preco_v=None, quant=None, data_E=None, fk_id_cli=None, fk_id_jog=None, fk_id_est=None):
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try:
        conexao = criar_conexao()   # Abre conexão
        cursor = conexao.cursor() 

        atualizacoes = [] # Lista para armazenar partes do SQL que vão mudar
        valores = [] # Lista para armazenar os valores correspondentes

        # Para cada campo, adiciona ao SQL e ao valores
        if nota_fiscal:
            atualizacoes.append("nota_fiscal = %s")
            valores.append(nota_fiscal)
        if preco_v:
            atualizacoes.append("preco_v = %s")
            valores.append(preco_v)
        if quant:
            atualizacoes.append("quant = %s")
            valores.append(quant)
        if data_E:
            atualizacoes.append("data_E = %s")
            valores.append(data_E)
        if fk_id_cli:
            atualizacoes.append("fk_id_cli = %s")
            valores.append(fk_id_cli)
        if fk_id_jog:
            atualizacoes.append("fk_id_jog = %s")
            valores.append(fk_id_jog)
        if fk_id_est:
            atualizacoes.append("fk_id_est = %s")
            valores.append(fk_id_est)

        # Se nada for atualizado, retorna
        if not atualizacoes:
            print("Nenhum campo para atualizar.")
            return

        sql = f"UPDATE venda SET {', '.join(atualizacoes)} WHERE pk_id = %s" # Comando SQL para UPDATE pelo pk_id
        valores.append(pk_id)

        cursor.execute(sql, valores) # Executa o comando com os valores
        conexao.commit() # Confirma a atualização

        # Verifica se alguma linha foi alterada
        if cursor.rowcount:
            print("Venda atualizada com sucesso!")
            return True, "Venda atualizada com sucesso!" # Retorna Sucesso
        else:
            print("Venda não encontrada.")

    except mysql.connector.Error as erro:
        print(f"Erro ao atualizar venda: {erro}")
        return False, f"Erro ao atualizar venda: {erro}" # Retorna Falso

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close() # Fecha a conexão

def deletar_venda(pk_id):
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try:
        conexao = criar_conexao() # Abre conexão
        cursor = conexao.cursor()

        sql = "DELETE FROM venda WHERE pk_id = %s" # Comando SQL para DELETE pelo pk_id
        valor = (pk_id, )

        cursor.execute(sql, valor) # Executa o comando com os valores
        conexao.commit() # Confirma a atualização

        # Verifica se alguma linha foi alterada
        if cursor.rowcount:
            print("Venda deletada com sucesso!")
            return True, "Venda deletada com sucesso!" # Retorna Sucesso
        else:
            print("Venda não encontrada.")

    except mysql.connector.Error as erro:
        print(f"Erro ao deletar venda: {erro}")
        return False, f"Erro ao deletar venda: {erro}" # Retorna Falso

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close() # Fecha a conexão
