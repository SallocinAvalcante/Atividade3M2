import customtkinter as ctk
from CTkMessagebox import CTkMessagebox
from PIL import Image, ImageTk
import clientes  # Importa as funções de clientes.py

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

# Funções
def inserir_cliente():
    cpf = entry_cpf.get()
    nome = entry_nome.get()
    email = entry_email.get()
    senha = entry_senha.get()
    endereco = entry_endereco.get()

    sucesso, mensagem = clientes.inserir_cliente(cpf, nome, email, senha, endereco)

    if sucesso:
        CTkMessagebox(title="Sucesso", message=mensagem, icon="check", button_color="#8A2BE2", button_hover_color="#A020F0")
        limpar_tela()
    else:
        CTkMessagebox(title="Erro", message=mensagem, icon="cancel", button_color="#8A2BE2", button_hover_color="#A020F0")

def consultar_cliente():
    cpf = entry_cpf.get()

    if not cpf:
        CTkMessagebox(title="Consulta", message="Por favor, informe o CPF para consultar.", icon="warning", button_color="#8A2BE2", button_hover_color="#A020F0")
        return
    
    cliente = clientes.consultar_cliente_cpf(cpf)

    if cliente:
        entry_nome.delete(0, ctk.END)
        entry_nome.insert(0, cliente[1])

        entry_email.delete(0, ctk.END)
        entry_email.insert(0, cliente[2])

        entry_senha.delete(0, ctk.END)

        entry_endereco.delete(0, ctk.END)
        entry_endereco.insert(0, cliente[3])

        CTkMessagebox(title="Consulta", message=f"Cliente encontrado:\nNome: {cliente[0]}\nEmail: {[1]}\nSenha: {cliente[2]}\nEndereço: {cliente[3]}",
                      icon="check", button_color="#8A2BE2",button_hover_color="#A020F0")
    else:
        CTkMessagebox(title="Consulta", message="Cliente não encontrado.", icon="warning")

def mostrar_todos_clientes():
    clientes_lista = clientes.exibir_clientes()

    if not clientes_lista:
        CTkMessagebox(title="Consulta", message="Nenhum cliente encontrado.", icon="warning", button_color="#8A2BE2", button_hover_color="#A020F0")
        return
    clientes_str = "CPF - Nome - Email - Senha - Endereço\n\n"
    for cliente in clientes_lista:
        clientes_str += f"\n{cliente[0]} - {cliente[1]} - {cliente[2]} - {cliente[3]} - {cliente[4]}\n"

    CTkMessagebox(title="Todos os Clientes", message=clientes_str, icon="Icone_NewGames.ico", width=800, height=300,
                   button_color="#8A2BE2", button_hover_color="#A020F0")

def atualizar_cliente():
    cpf = entry_cpf.get()
    nome = entry_nome.get()
    email = entry_email.get()
    senha = entry_senha.get()
    endereco = entry_endereco.get()

    sucesso, mensagem = clientes.atualizar_cliente(cpf, nome, email, senha, endereco)

    if sucesso:
        CTkMessagebox(title="Sucesso", message=mensagem, icon="check", button_color="#8A2BE2", button_hover_color="#A020F0")
        limpar_tela()
    else:
        CTkMessagebox(title="Erro", message=mensagem, icon="cancel", button_color="#8A2BE2", button_hover_color="#A020F0")

def deletar_cliente():
    cpf = entry_cpf.get()

    sucesso, mensagem = clientes.deletar_cliente(cpf)

    if sucesso:
        CTkMessagebox(title="Sucesso", message=mensagem, icon="check", button_color="#8A2BE2", button_hover_color="#A020F0")
        limpar_tela()
    else:
        CTkMessagebox(title="Erro", message=mensagem, icon="cancel", button_color="#8A2BE2", button_hover_color="#A020F0")

def limpar_tela():
    entry_cpf.delete(0, ctk.END)
    entry_nome.delete(0, ctk.END)
    entry_email.delete(0, ctk.END)
    entry_senha.delete(0, ctk.END)
    entry_endereco.delete(0, ctk.END)
    entry_cpf.focus()

def sair():
    opcao = CTkMessagebox(title="Sair", message="Deseja sair?", icon="question", option_2="Sim", option_1="Não", button_color="#8A2BE2", button_hover_color="#A020F0")
    if opcao.get() == "Sim":
        janela.destroy()

# Janela principal
janela = ctk.CTk()
janela.title("Cadastro de Clientes")
janela.geometry("400x600")
janela.resizable(False, False)
janela.iconbitmap("Icone_NewGames.ico")

# Imagem no canto superior esquerdo (cabeçalho)
imagem = Image.open("Logo_NewGames.png")
imagem = imagem.resize((200, 85))  # Ajustar o tamanho da imagem
imagem_tk = ImageTk.PhotoImage(imagem)
# Frame do cabeçalho
frame_topo = ctk.CTkFrame(janela, fg_color="transparent")
frame_topo.pack(pady=10, anchor='w')  # Alinha à esquerda
label_imagem = ctk.CTkLabel(frame_topo, image=imagem_tk, text="")
label_imagem.pack(side="left", padx=10)

# Campos de entrada
entry_cpf = ctk.CTkEntry(janela, placeholder_text="CPF")
entry_cpf.pack(pady=10, padx=20, fill="x")

entry_nome = ctk.CTkEntry(janela, placeholder_text="Nome")
entry_nome.pack(pady=10, padx=20, fill="x")

entry_email = ctk.CTkEntry(janela, placeholder_text="Email")
entry_email.pack(pady=10, padx=20, fill="x")

entry_senha = ctk.CTkEntry(janela, placeholder_text="Senha")
entry_senha.pack(pady=10, padx=20, fill="x")

entry_endereco = ctk.CTkEntry(janela, placeholder_text="Endereço")
entry_endereco.pack(pady=10, padx=20, fill="x")

# Estilo padrão dos botões
botao_estilo = {
    "width": 100,
    "height": 30,
    "font": ("Arial", 14),
    "corner_radius": 10,
    "fg_color": "#8A2BE2",  # Roxo
    "hover_color": "#A020F0",  # Roxo mais claro
    "text_color": "white"
}

# Botões
frame_botoes = ctk.CTkFrame(janela, fg_color="transparent")
frame_botoes.pack(pady=20)

btn_cadastrar = ctk.CTkButton(frame_botoes, text="Cadastrar", command=inserir_cliente, **botao_estilo)
btn_cadastrar.grid(row=0, column=0, padx=10, pady=5)

btn_consultar = ctk.CTkButton(frame_botoes, text="Consultar", command=consultar_cliente, **botao_estilo)
btn_consultar.grid(row=0, column=1, padx=10, pady=5)

btn_atualizar = ctk.CTkButton(frame_botoes, text="Atualizar", command=atualizar_cliente, **botao_estilo)
btn_atualizar.grid(row=1, column=0, padx=10, pady=5)

btn_deletar = ctk.CTkButton(frame_botoes, text="Deletar", command=deletar_cliente, **botao_estilo)
btn_deletar.grid(row=1, column=1, padx=10, pady=5)

btn_mostrar_todos = ctk.CTkButton(janela, text="Mostrar Todos", command=mostrar_todos_clientes, **botao_estilo)
btn_mostrar_todos.pack(pady=10, padx=20, fill="x")

btn_sair = ctk.CTkButton(janela, text="Sair", command=sair, fg_color="red", hover_color="dark red")
btn_sair.pack(pady=10, padx=20, fill="x")

janela.mainloop()