# Autores: Augusto Corrêa da Rocha Neto RGM:11221101575 (Código) Gleydson Akiriro RGM: 11221103498  Nicollas Cavalcante RGM:11221104304 - Estrutura lineares - Atividade 3 M2
#Bibliotecas
import customtkinter as ctk
from CTkMessagebox import CTkMessagebox
from PIL import Image
import matplotlib as mplt
import numpy as np
import subprocess # Biblioteca para abrir outras janelas de arquivos python

# Configura o tema
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

# Funções para abrir outras janelas 
def abrir_chatbot():
    CTkMessagebox(title="Chatbot", message= "Abrindo interface de Chatbot...", button_color="#8A2BE2", button_hover_color="#A020F0")
    subprocess.Popen(["python", "chatbot_jogo.py"])

def abrir_cadastrar_jogo():
    CTkMessagebox(title="Cadastrar Jogo", message= "Abrindo interface de cadastro de novo jogo...", button_color="#8A2BE2", button_hover_color="#A020F0")
    subprocess.Popen(["python", "jogos_GUI.py"])

def abrir_cadastrar_clientes():
    CTkMessagebox(title="Cadastrar Cliente", message= "Abrindo interface de cadastro de novo cliente...", button_color="#8A2BE2", button_hover_color="#A020F0")
    subprocess.Popen(["python", "clientes_GUI.py"])

def abrir_cadastrar_estoque():
    CTkMessagebox(title="Cadastrar Estoque", message= "Abrindo interface de cadastro de novo estoque...", button_color="#8A2BE2", button_hover_color="#A020F0")
    subprocess.Popen(["python", "estoque_GUI.py"])

def abrir_cadastrar_vendas():
    CTkMessagebox(title="Cadastrar Vendas", message= "Abrindo interface de cadastro de nova venda...", button_color="#8A2BE2", button_hover_color="#A020F0")
    subprocess.Popen(["python", "Venda_GUI.py"])

def abrir_lojas_filiais():
    CTkMessagebox(title="Lojas Filiais", message= "Abrindo mapa de lojas filiais...", button_color="#8A2BE2", button_hover_color="#A020F0")
    subprocess.Popen(["python", "Lojas_Filiais.py"])

# Criação de Janela
janela = ctk.CTk()
janela.title("New Games - Menu Principal")
janela.geometry("800x500+100+200")
janela.resizable(False, False)
janela.iconbitmap("Icone_NewGames.ico")

# Carregando a imagem
logo_image = ctk.CTkImage(
    light_image=Image.open("Logo_NewGames.png"), 
    dark_image=Image.open("Logo_NewGames.png"), 
    size=(400, 150)  # ajuste do tamanho da imagem
)

# Label com a imagem
logo_label = ctk.CTkLabel(janela, image=logo_image, text="")  # text vazio para não mostrar texto
logo_label.pack(pady=(30, 10))

# Frame dos Botões
frame_botoes = ctk.CTkFrame(janela, fg_color="transparent")
frame_botoes.pack(pady=20)

# Estilo padrão dos botões
botao_estilo = {
    "width": 200,
    "height": 50,
    "font": ("Arial", 14, "bold"),
    "corner_radius": 10,
    "fg_color": "#8A2BE2",  # Roxo
    "hover_color": "#A020F0",  # Roxo mais claro
    "text_color": "white"
}

# Linha 1 de botões
b1 = ctk.CTkButton(frame_botoes, text="🤖 Conversar com o GameBot", command=abrir_chatbot, **botao_estilo)
b1.grid(row=0, column=0, padx=20, pady=15)

b2 = ctk.CTkButton(frame_botoes, text="🎮 Cadastrar Novo Jogo", command=abrir_cadastrar_jogo, **botao_estilo)
b2.grid(row=0, column=1, padx=20, pady=15)

b3 = ctk.CTkButton(frame_botoes, text="🧑 Cadastrar Novo Cliente", command=abrir_cadastrar_clientes, **botao_estilo)
b3.grid(row=0, column=2, padx=20, pady=15)

# Linha 2 de botões
b4 = ctk.CTkButton(frame_botoes, text="📦 Cadastrar Novo Estoque", command=abrir_cadastrar_estoque, **botao_estilo)
b4.grid(row=1, column=0, padx=20, pady=15)

b5 = ctk.CTkButton(frame_botoes, text="🛒 Cadastrar Nova Venda", command=abrir_cadastrar_vendas, **botao_estilo)
b5.grid(row=1, column=1, padx=20, pady=15)

b6 = ctk.CTkButton(frame_botoes, text="📍 Lojas Filiais", command=abrir_lojas_filiais, **botao_estilo)
b6.grid(row=1, column=2, padx=20, pady=15)

# Rodapé
rodape = ctk.CTkLabel(janela, text="New Games © 2025", font=("Arial", 10))
rodape.pack(side="bottom", pady=20)

# Loop de Interface
janela.mainloop()