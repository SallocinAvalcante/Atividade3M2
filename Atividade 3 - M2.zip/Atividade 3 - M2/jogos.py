# Autores: Augusto Corrêa da Rocha Neto RGM:11221101575 (Código) Gleydson Akiriro RGM: 11221103498  Nicollas Cavalcante RGM:11221104304 - Estrutura lineares - Atividade 3 M2
#Bibliotecas
import mysql.connector

#Funções
# Função para criar a conexão com o banco de dados
def criar_conexao():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="new_games"
    )

def inserir_jogo(id, nome, genero, plataforma, preco_bruto):
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try: 
        conexao = criar_conexao() # Abre a conexão com o banco
        cursor = conexao.cursor()

        sql = "INSERT INTO jogos (id, nome, genero, plataforma, preco_bruto) VALUES (%s, %s, %s, %s, %s)" # Comando SQL para INSERT
        valores = (id, nome, genero, plataforma, preco_bruto)

        cursor.execute(sql, valores) # Executa o comando
        conexao.commit() # Confirma a inserção

        print("Jogo inserido com sucesso!")
        return True, "Jogo inserido com sucesso!" # Retorna Sucesso

    except mysql.connector.Error as erro:
        print(f"Erro ao inserir jogo: {erro}")
        return False, f"Erro ao inserir: {erro}" # Retorna Falso

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close() # Fecha a conexão

def consultar_jogo_id(id):
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try:
        conexao = criar_conexao() # Abre conexão com o banco
        cursor = conexao.cursor()

        sql = "SELECT nome, genero, plataforma, preco_bruto FROM jogos  WHERE id = %s" # Comando SQL para SELECT de um jogo pelo id
        cursor.execute(sql,(id,)) # Criar uma tupla

        jogo = cursor.fetchone() # Busca apenas um jogo que corresponde ao id

        return jogo  # retorna uma tupla ou None

    except mysql.connector.Error as erro:
        print(f"Erro ao consultar cliente: {erro}")
        return None

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close() # Fecha a conexão

def exibir_jogos():
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try:
        # Abre conexão
        conexao = criar_conexao() # Abre a conexão com o banco
        cursor = conexao.cursor()

        # SQL de consulta
        sql = "SELECT id, nome, genero, plataforma, preco_bruto FROM jogos" # Comando SQL para SELECT de todos os jogos
        cursor.execute(sql)

        resultados = cursor.fetchall() # Cria uma lista e busca por todos os jogos

        return resultados  # retorna a lista

    except mysql.connector.Error as erro:
        print(f"Erro ao consultar jogos: {erro}")
        return [] # Garante que sempre retorna uma lista, mesmo no erro

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close() # Fecha a conexão

def atualizar_jogo(id, nome=None, genero=None, plataforma=None, preco_bruto=None):
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try:
        conexao = criar_conexao() # Abre conexão
        cursor = conexao.cursor() 

        atualizacoes = [] # Lista para armazenar partes do SQL que vão mudar
        valores = [] # Lista para armazenar os valores correspondentes

        # Para cada campo, adiciona ao SQL e ao valores
        if nome:
            atualizacoes.append("nome = %s")
            valores.append(nome)
        if genero:
            atualizacoes.append("genero = %s")
            valores.append(genero)
        if plataforma:
            atualizacoes.append("plataforma = %s")
            valores.append(plataforma)
        if preco_bruto:
            atualizacoes.append("preco_bruto = %s")
            valores.append(preco_bruto)

        # Se nada for atualizado, retorna
        if not atualizacoes:
            print("Nenhum campo para atualizar.")
            return

        sql = f"UPDATE jogos SET {', '.join(atualizacoes)} WHERE id = %s" # Comando SQL para UPDATE pelo id
        valores.append(id) 

        cursor.execute(sql, valores) # Executa o comando com os valores
        conexao.commit() # Confirma a atualização

        # Verifica se alguma linha foi alterada
        if cursor.rowcount:
            print("Jogo atualizado com sucesso!")
            return True, "Jogo atualizado com sucesso!" # Retorna Sucesso
        else:
            print("Jogo não encontrado.")

    except mysql.connector.Error as erro:
        print(f"Erro ao atualizar jogo: {erro}")
        return False, f"Erro ao inserir: {erro}" # Retorna Falso

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close() # Fecha a conexão

def deletar_jogo(id):
    conexao = None # Garante que a variável exista no escopo inteiro da função, evitando erros e permitindo um fechamento seguro da conexão
    try:
        conexao = criar_conexao() # Abre conexão
        cursor = conexao.cursor()

        sql = "DELETE FROM jogos WHERE id = %s" # Comando SQL para DELETE pelo cid
        valor = (id, )

        cursor.execute(sql, valor) # Executa o comando com os valores
        conexao.commit() # Confirma a atualização

        # Verifica se alguma linha foi alterada
        if cursor.rowcount:
            print("Jogo deletado com sucesso!")
            return True, "Jogo deletado com sucesso!" # Retorna Sucesso
        else:
            print("Jogo não encontrado.")

    except mysql.connector.Error as erro:
        print(f"Erro ao deletar jogo: {erro}")
        return False, f"Erro ao deletar jogo: {erro}" # Retorna Falso

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close() # Fecha a conexão
